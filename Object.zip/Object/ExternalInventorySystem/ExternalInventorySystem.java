package ExternalInventorySystem;
import ItemDTO.ItemDTO;
public class ExternalInventorySystem {
    public ItemDTO findItem(String itemIdentifier){
        if(itemIdentifier.equals("aaa111")){
            return new ItemDTO("schampo", 0, 5, "abc111");
        }
        else if(itemIdentifier.equals("aaa112")){
            return new ItemDTO("pasta penne",6,6.5,"aaa112");
        }
        else{
            return null;
        }

    }
    
    
}
