package Receipt; 
import sale.sale;
import ItemDTO.ItemDTO;
import SoldItem.SoldItem;
public class Receipt {
    private sale sale;

    public Receipt(sale sale) {
        this.sale = sale;
    }

    public void generate() {
       
       
        System.out.println("Date: " + sale.getSaleTime());
       

        
        for (SoldItem soldItem : sale.getSoldItems()) {
            ItemDTO item = soldItem.getItem();
            int quantity = soldItem.getQuantity();
            double price = item.getPrice();
            double totalItemPrice = soldItem.getTotalPriceWithVAT();
            
            System.out.println(item.getName() + " (" + quantity + " x " + price + "): " + totalItemPrice);
        }

    
        double totalPrice = sale.getTotalPriceIncludingVAT();
        
        System.out.println("Total price: " + totalPrice);

        System.out.println("Thank you for shopping!");
        
    }
}