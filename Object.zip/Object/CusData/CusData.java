package CusData;
public class CusData {

    
    public double getDiscount(int age) {
        if (age < 20 || age > 70) {
            return 0.9; 
        } else {
            return 1.0; 
        }
    }
}
