package AcoSystem;
import sale.sale;
public class AcoSystem  {
    public void addToAco(sale sale){
        System.out.println("sale är i bokfäringen");
    }

}
