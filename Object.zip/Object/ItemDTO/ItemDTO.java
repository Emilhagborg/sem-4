package ItemDTO;

public class ItemDTO {
    private final String name;
    private final int VAT;
    private final double price;
    private final String identifier;

    public ItemDTO(String name, int VAT, double price, String identifier) {
        this.name = name;
        this.VAT = VAT;
        this.price = price;
        this.identifier = identifier;
    }

    public String getName() {
        return name;
    }

    public int getVAT() {
        return VAT;
    }

    public double getPrice() {
        return price;
    }

    public String getIdentifier() {
        return identifier;
    }
}