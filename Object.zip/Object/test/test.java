package test;


import ItemDTO.ItemDTO;

public class test {
    public static void main(String[] args) {
        ItemDTO pasta = new ItemDTO("Schampo", 0, 5.0, "abc111");
        System.out.println(pasta);
    }
}