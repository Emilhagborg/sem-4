package sale;
import SoldItem.SoldItem;
import ItemDTO.ItemDTO;
import Receipt.Receipt;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class sale {
    private LocalDateTime saleTime;
    private List<SoldItem> soldItems;
    
    public void startSale() {
        this.saleTime = LocalDateTime.now();
        this.soldItems = new ArrayList<>();
        
    }

    public void registerItem(ItemDTO item, int quantity) {
        for (SoldItem soldItem : soldItems) {
            if (soldItem.getItem().getIdentifier().equals(item.getIdentifier())) {
                soldItem.increaseQuantity(quantity); 
                return;
            }
        }
        soldItems.add(new SoldItem(item, quantity)); 
    }

    public double getTotalPriceIncludingVAT() {
        double total = 0;
        for (SoldItem item : soldItems) {
            total += item.getTotalPriceWithVAT();
        }
        return total;
    }

    public LocalDateTime getSaleTime() {
        return saleTime;
    }
    public void endSale(){
        Receipt receipt = new Receipt(this);
        receipt.generate();
    }

    public List<SoldItem> getSoldItems() {
        return soldItems;
       
    }
    

}