package view;

import controller.Controller;

import java.util.Scanner;

public class view {
    private Controller controller;
    private Scanner scanner;

    public view(Controller controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        controller.startSale(); 

        // Loop tills alla varor är slut
        while (true) {
            System.out.println("skanna varor tills du skriver slut");
            String itemIdentifier = scanner.nextLine();

            if (itemIdentifier.equalsIgnoreCase("slut")) {
                break;
            }

            System.out.println("Enter quantity:");
            int quantity = Integer.parseInt(scanner.nextLine());

            controller.registerItem(itemIdentifier, quantity); 
        }
    }
 }