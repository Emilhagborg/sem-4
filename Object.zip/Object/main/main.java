package main;
import  controller.Controller;
import view.view;
public class main{
    public static void main(String[] args){
        Controller contr= new Controller();
        new view(contr);

    }
}