package controller;

import sale.sale;
import ExternalInventorySystem.ExternalInventorySystem;
import AcoSystem.AcoSystem;
import CusData.CusData;
import ItemDTO.ItemDTO;
public class Controller {
    private sale sale;
    private ExternalInventorySystem externalInventorySystem;
    private AcoSystem acoSystem;
    private  CusData cusData;


    public Controller() {
        this.sale = new sale();
        this.externalInventorySystem = new ExternalInventorySystem();
        this.cusData = new CusData();
        this.acoSystem= new AcoSystem();
    }

    public void startSale() {
        sale = new sale();

    }

    public void registerItem(String itemIdentifier, int quantity) {
        ItemDTO item = externalInventorySystem.findItem(itemIdentifier);
        if (item != null) {
            sale.registerItem(item, quantity);
        }
    }
    public void applyDiscount(int customerAge) {
        double discount = cusData.getDiscount(customerAge);
    }
    public void addToAco(sale sale){
        acoSystem.addToAco(sale);
    }

}